package com.chung.tv3;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PictureInPictureParams;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.util.Rational;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;

/**
 * TV 3 Trong 1.
 * - ui:   giao diện chính (assets/index.html): màn hình chính + Xem TV (phát kênh bằng hls.js).
 * - site: WebView thứ hai mở trang bóng đá / trang phim, có chặn quảng cáo.
 * Giữ nút Back 1 giây = về màn hình chính của app.
 */
public class MainActivity extends Activity {

    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "popads.net", "popcash.net", "propellerads.com", "adsterra.com", "exoclick.com",
            "juicyads.com", "trafficjunky.com", "clickadu.com", "hilltopads.net", "onclickads.net",
            "ad-maven.com", "admaven.com", "monetag.com", "a-ads.com", "adnxs.com", "taboola.com",
            "outbrain.com", "mgid.com", "revcontent.com", "admicro.vn", "eclick.vn", "adtima.vn",
            "popunder.net", "adcash.com", "richpartners.com", "tsyndicate.com", "syndication.realsrv.com"
    };

    private static final String BLOCK_JS =
            "(function(){try{"
            + "if(window.__tv3)return;window.__tv3=1;"
            + "window.open=function(){return null};"
            + "var css=\"ins.adsbygoogle,iframe[src*='doubleclick'],iframe[src*='googlesyndication'],"
            + "[id^='google_ads'],[class*='banner-ads'],[class*='ads-banner'],[class*='popup-ads'],"
            + "[id*='popup-ads'],[class*='adsbox'],[class*='ad-overlay'],[id*='ad-overlay']"
            + "{display:none!important}\";"
            + "var s=document.createElement('style');s.textContent=css;"
            + "(document.head||document.documentElement).appendChild(s);"
            + "}catch(e){}})();";

    private FrameLayout root;
    private WebView ui;
    private WebView site;
    private LinearLayout bar;
    private LinearLayout panel;
    private TextView btnPip;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private SharedPreferences prefs;

    private String kind = null;        // "ball" hoặc "movie" khi đang mở trang web
    private String loadedKind = null;
    private boolean firstLoad = true;
    private boolean clearHist = false;
    private boolean longHandled = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0A0E15);
        setContentView(root);

        ui = new WebView(this);
        setupUi();
        root.addView(ui, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        site = new WebView(this);
        setupSite();
        site.setVisibility(View.GONE);
        root.addView(site, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        buildBar();
        ui.loadUrl("file:///android_asset/index.html");
    }

    // ---------- giao diện chính ----------
    @SuppressWarnings("deprecation")
    private void setupUi() {
        WebSettings s = ui.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        ui.setBackgroundColor(0xFF0A0E15);
        ui.addJavascriptInterface(new Bridge(), "Android");
        ui.setWebChromeClient(new WebChromeClient());
        ui.setWebViewClient(new WebViewClient());
    }

    private class Bridge {
        @JavascriptInterface
        public void openSite(final String k) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showSite(k);
                }
            });
        }
    }

    // ---------- trang bóng đá / phim ----------
    private void setupSite() {
        WebSettings s = site.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));
        CookieManager.getInstance().setAcceptThirdPartyCookies(site, true);
        site.setBackgroundColor(Color.BLACK);

        site.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (isAd(r.getUrl().getHost())) {
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (!u.startsWith("http")) return true;           // chặn mở app/lạ
                if (isAd(r.getUrl().getHost())) return true;
                if (!r.isForMainFrame()) return false;
                if (firstLoad || r.hasGesture() || sameSite(r.getUrl().getHost())) return false;
                return true;                                      // tự nhảy sang trang khác khi không bấm: chặn
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                super.onPageStarted(v, url, favicon);
                applyOrientationFor(url);
                v.evaluateJavascript(BLOCK_JS, null);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                super.onPageFinished(v, url);
                if (!"about:blank".equals(url)) {
                    firstLoad = false;
                    if (clearHist) {
                        v.clearHistory();
                        clearHist = false;
                    }
                }
                v.evaluateJavascript(BLOCK_JS, null);
            }
        });

        site.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                return false; // chặn popup
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCb = cb;
                view.setBackgroundColor(Color.BLACK);
                root.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                bar.setVisibility(View.GONE);
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                hideSystemBars();
            }

            @Override
            public void onHideCustomView() {
                exitCustom();
            }
        });
    }

    private String siteUrl(String k) {
        if (k == null) return "about:blank";
        String def = "ball".equals(k) ? "https://gavangtvttbdi.tv" : "https://www.500phim.net";
        return prefs.getString("url_" + k, def);
    }

    private static String base(String h) {
        if (h == null) return "";
        String[] p = h.split("\\.");
        int n = p.length;
        return n >= 2 ? p[n - 2] + "." + p[n - 1] : h;
    }

    private boolean sameSite(String host) {
        Uri cur = Uri.parse(siteUrl(kind));
        return base(cur.getHost()).equals(base(host));
    }

    private static boolean isAd(String host) {
        if (host == null) return false;
        for (String h : AD_HOSTS) {
            if (host.equals(h) || host.endsWith("." + h)) return true;
        }
        return false;
    }

    private void applyOrientationFor(String url) {
        if (!"ball".equals(kind) || url == null) return;
        Uri u = Uri.parse(url);
        String path = u.getPath();
        boolean atRoot = path == null || path.length() <= 1;
        setRequestedOrientation(atRoot
                ? ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
                : ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE); // chọn trận thì tự xoay ngang
    }

    private void showSite(String k) {
        kind = k;
        ui.setVisibility(View.GONE);
        site.setVisibility(View.VISIBLE);
        bar.setVisibility(View.VISIBLE);
        panel.setVisibility(View.VISIBLE);
        btnPip.setVisibility("ball".equals(k) ? View.VISIBLE : View.GONE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
        showSystemBars();
        if (!k.equals(loadedKind)) {
            loadedKind = k;
            firstLoad = true;
            clearHist = true;
            site.loadUrl(siteUrl(k));
        }
        site.requestFocus();
    }

    private void hideSite() {
        site.loadUrl("about:blank"); // dừng tiếng và video
        loadedKind = null;
        kind = null;
        site.setVisibility(View.GONE);
        bar.setVisibility(View.GONE);
        ui.setVisibility(View.VISIBLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        hideSystemBars();
        ui.requestFocus();
    }

    private void exitCustom() {
        if (customView == null) return;
        View v = customView;
        WebChromeClient.CustomViewCallback cb = customCb;
        customView = null;
        customCb = null;
        root.removeView(v);
        if (cb != null) cb.onCustomViewHidden();
        if (site.getVisibility() == View.VISIBLE) {
            bar.setVisibility(View.VISIBLE);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
            showSystemBars();
        }
    }

    // ---------- thanh nút nổi ----------
    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView mk(LinearLayout parent, String text, View.OnClickListener l) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(15);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xD9121927);
        g.setCornerRadius(dp(18));
        g.setStroke(dp(1), 0xFF29344C);
        v.setBackground(g);
        v.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(6);
        parent.addView(v, lp);
        return v;
    }

    private void buildBar() {
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);

        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        bar.addView(panel);

        mk(panel, "Màn hình chính", new View.OnClickListener() {
            @Override public void onClick(View v) { goHomeAll(); }
        });
        mk(panel, "Lùi", new View.OnClickListener() {
            @Override public void onClick(View v) { handleBack(); }
        });
        mk(panel, "Tải lại", new View.OnClickListener() {
            @Override public void onClick(View v) { site.reload(); }
        });
        btnPip = mk(panel, "Thu nhỏ", new View.OnClickListener() {
            @Override public void onClick(View v) { enterPip(); }
        });
        mk(panel, "Đổi link", new View.OnClickListener() {
            @Override public void onClick(View v) { changeLinkDialog(); }
        });
        mk(bar, "Menu", new View.OnClickListener() {
            @Override public void onClick(View v) {
                panel.setVisibility(panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.END);
        lp.topMargin = dp(8);
        lp.rightMargin = dp(8);
        bar.setVisibility(View.GONE);
        root.addView(bar, lp);
    }

    private void changeLinkDialog() {
        final String k = kind;
        if (k == null) return;
        final EditText et = new EditText(this);
        et.setText(siteUrl(k));
        et.setSingleLine(true);
        et.setSelection(et.getText().length());
        new AlertDialog.Builder(this)
                .setTitle("ball".equals(k) ? "Link trang bóng đá" : "Link trang phim")
                .setMessage("Khi trang đổi tên miền, nhập link mới. App dùng link này từ giờ, không cần cài lại.")
                .setView(et)
                .setPositiveButton("Lưu", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        String v = et.getText().toString().trim();
                        if (v.isEmpty()) return;
                        if (!v.startsWith("http")) v = "https://" + v;
                        prefs.edit().putString("url_" + k, v).apply();
                        firstLoad = true;
                        clearHist = true;
                        loadedKind = k;
                        site.loadUrl(v);
                        Toast.makeText(MainActivity.this, "Đã đổi link", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    // ---------- thu nhỏ (hình trong hình) ----------
    private void enterPip() {
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                enterPictureInPictureMode(new PictureInPictureParams.Builder()
                        .setAspectRatio(new Rational(16, 9)).build());
            } catch (Exception e) {
                Toast.makeText(this, "Không thu nhỏ được trên máy này", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Máy không hỗ trợ thu nhỏ", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean inPip, Configuration cfg) {
        super.onPictureInPictureModeChanged(inPip, cfg);
        if (inPip) {
            bar.setVisibility(View.GONE);
        } else if (site.getVisibility() == View.VISIBLE && customView == null) {
            bar.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (Build.VERSION.SDK_INT >= 26 && site.getVisibility() == View.VISIBLE
                && "ball".equals(kind) && !isInPictureInPictureMode()) {
            enterPip();
        }
    }

    // ---------- thanh hệ thống ----------
    @SuppressWarnings("deprecation")
    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @SuppressWarnings("deprecation")
    private void showSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && (site.getVisibility() != View.VISIBLE || customView != null)) hideSystemBars();
    }

    // ---------- phím Back: bấm = lùi, giữ 1 giây = về màn hình chính ----------
    private void handleBack() {
        if (customView != null) {
            exitCustom();
            return;
        }
        if (site.getVisibility() == View.VISIBLE) {
            if (site.canGoBack()) site.goBack();
            else hideSite();
            return;
        }
        ui.evaluateJavascript("window.tvBack?window.tvBack():false", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (!"true".equals(v)) finish();
            }
        });
    }

    private void goHomeAll() {
        if (customView != null) exitCustom();
        if (site.getVisibility() == View.VISIBLE) hideSite();
        ui.evaluateJavascript("window.tvHome&&window.tvHome()", null);
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK) {
            e.startTracking();
            return true;
        }
        return super.onKeyDown(code, e);
    }

    @Override
    public boolean onKeyLongPress(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK) {
            longHandled = true;
            goHomeAll();
            return true;
        }
        return super.onKeyLongPress(code, e);
    }

    @Override
    public boolean onKeyUp(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK) {
            if (longHandled) {
                longHandled = false;
                return true;
            }
            if (e.isCanceled()) return true;
            handleBack();
            return true;
        }
        return super.onKeyUp(code, e);
    }

    @Override
    protected void onDestroy() {
        ui.destroy();
        site.destroy();
        super.onDestroy();
    }
}
