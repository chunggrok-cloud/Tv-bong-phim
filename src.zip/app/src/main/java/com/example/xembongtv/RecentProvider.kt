package com.example.xembongtv

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import org.json.JSONArray
import java.io.File
import java.io.FileNotFoundException

/**
 * Cho launcher (TV Home) đọc 3 kênh xem gần đây và logo của chúng.
 *   content://com.chung.tv3.recent/recent        -> danh sách (id, name, logo, hue)
 *   content://com.chung.tv3.recent/logo/<tên file> -> file logo trong assets/logos
 *   content://com.chung.tv3.recent/movies         -> phim "Xem tiếp" (title, url, poster, progress, label)
 *   content://com.chung.tv3.recent/poster/<tên file> -> poster phim đã tải
 * Chỉ đọc, không ghi.
 */
class RecentProvider : ContentProvider() {
    override fun onCreate(): Boolean = true

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?,
                       selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val sp = context!!.getSharedPreferences("xembongtv", Context.MODE_PRIVATE)
        if (uri.lastPathSegment == "movies") {
            val m = MatrixCursor(arrayOf("title", "url", "poster", "progress", "label"))
            try {
                val a = JSONArray(sp.getString("movies_pub", "[]"))
                for (i in 0 until minOf(3, a.length())) {
                    val o = a.getJSONObject(i)
                    m.addRow(arrayOf<Any>(o.optString("title"), o.optString("url"), o.optString("poster"),
                        o.optDouble("progress", 0.0), o.optString("label")))
                }
            } catch (e: Exception) {
            }
            return m
        }
        val c = MatrixCursor(arrayOf("id", "name", "logo", "hue"))
        try {
            val a = JSONArray(sp.getString("recent_pub", "[]"))
            for (i in 0 until minOf(3, a.length())) {
                val o = a.getJSONObject(i)
                c.addRow(arrayOf<Any>(o.optString("id"), o.optString("name"), o.optString("logo"), o.optInt("h")))
            }
        } catch (e: Exception) {
        }
        return c
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val name = uri.lastPathSegment ?: throw FileNotFoundException()
        if (!Regex("[A-Za-z0-9_.-]+").matches(name)) throw FileNotFoundException()
        val ctx = context ?: throw FileNotFoundException()
        if (uri.pathSegments.firstOrNull() == "poster") {
            val pf = File(File(ctx.cacheDir, "posters"), name)
            if (!pf.exists()) throw FileNotFoundException()
            return ParcelFileDescriptor.open(pf, ParcelFileDescriptor.MODE_READ_ONLY)
        }
        val dir = File(ctx.cacheDir, "logos")
        dir.mkdirs()
        val f = File(dir, name)
        if (!f.exists()) {
            try {
                ctx.assets.open("logos/$name").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            } catch (e: Exception) {
                throw FileNotFoundException()
            }
        }
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun getType(uri: Uri): String = "vnd.android.cursor.dir/vnd.com.chung.tv3.recent"
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
