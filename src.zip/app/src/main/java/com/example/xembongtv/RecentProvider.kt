package com.example.xembongtv

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import org.json.JSONArray
import java.io.File
import java.io.FileNotFoundException

/**
 * Cho launcher (TV Home) đọc 3 kênh xem gần đây và logo của chúng.
 *   content://com.chung.tv3.recent/recent        -> danh sách (id, name, logo, hue)
 *   content://com.chung.tv3.recent/logo/<tên file> -> file logo trong assets/logos
 * Chỉ đọc, không ghi.
 */
class RecentProvider : ContentProvider() {
    override fun onCreate(): Boolean = true

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?,
                       selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val c = MatrixCursor(arrayOf("id", "name", "logo", "hue"))
        val sp = context!!.getSharedPreferences("xembongtv", Context.MODE_PRIVATE)
        try {
            val a = JSONArray(sp.getString("recent_pub", "[]"))
            for (i in 0 until minOf(3, a.length())) {
                val o = a.getJSONObject(i)
                c.addRow(arrayOf<Any>(o.optString("id"), o.optString("name"), o.optString("logo"), o.optInt("h")))
            }
        } catch (e: Exception) {
        }
        return c
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val name = uri.lastPathSegment ?: throw FileNotFoundException()
        if (!Regex("[A-Za-z0-9_.-]+").matches(name)) throw FileNotFoundException()
        val ctx = context ?: throw FileNotFoundException()
        val dir = File(ctx.cacheDir, "logos")
        dir.mkdirs()
        val f = File(dir, name)
        if (!f.exists()) {
            try {
                ctx.assets.open("logos/$name").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            } catch (e: Exception) {
                throw FileNotFoundException()
            }
        }
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun getType(uri: Uri): String = "vnd.android.cursor.dir/vnd.com.chung.tv3.recent"
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
