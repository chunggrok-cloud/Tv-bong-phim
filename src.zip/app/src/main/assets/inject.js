(function () {
  if (window.__fchaiInjected) return;
  window.__fchaiInjected = true;
  var ADBLOCK = window.__fchaiAdblock !== false;

  // ---------- tiện ích ----------
  function baseHost(h) { var p = String(h).split('.'); return p.slice(-2).join('.'); }
  var SITE = baseHost(location.hostname);
  function isExternal(u) {
    try {
      var x = new URL(u, location.href);
      if (x.protocol !== 'http:' && x.protocol !== 'https:') return false;
      return x.hostname.indexOf('gavang') === -1 && baseHost(x.hostname) !== SITE;
    } catch (e) { return false; }
  }
  function vw() { return window.innerWidth || document.documentElement.clientWidth; }
  function vh() { return window.innerHeight || document.documentElement.clientHeight; }
  function hide(el) {
    if (!el || el.__fchaiHidden) return;
    if (el.classList && el.classList.contains('fchai-player')) return;
    if (window.__fchaiEl && el.contains && el.contains(window.__fchaiEl)) return;
    el.__fchaiHidden = true;
    el.style.setProperty('display', 'none', 'important');
  }
  function isPlayerBox(el) {
    var r = el.getBoundingClientRect();
    if (r.width < vw() * 0.6 || r.height < 120) return false;
    var ratio = r.width / r.height;
    return ratio >= 1.4 && ratio <= 2.4;   // khung hình ~16:9
  }

  // ---------- chặn quảng cáo (phần hiển thị) ----------
  var AD_WORDS = /(^|[-_ ])(ads?|adv|advert\w*|popup|popunder|catfish|sponsor\w*|floating-?ad)([-_ ]|$)/i;
  function externalImgLink(el) {
    if (el.tagName === 'A') return isExternal(el.href) && !!el.querySelector('img');
    var as = el.querySelectorAll('a[href]');
    for (var i = 0; i < as.length; i++) {
      if (isExternal(as[i].href) && as[i].querySelector('img')) return true;
    }
    return false;
  }
  function cleanAds() {
    if (!ADBLOCK || !document.body) return;
    // 1) các khối quảng cáo quen thuộc
    var known = document.querySelectorAll('ins.adsbygoogle,[id^="google_ads"],[class*="adsbygoogle"],[id*="popunder"]');
    for (var k = 0; k < known.length; k++) hide(known[k]);
    // 2) banner dán cố định ở mép trên hoặc mép dưới màn hình
    var els = document.body.querySelectorAll('div,section,aside,a,iframe,ul');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (el.__fchaiHidden || el.__fchaiNotFixed) continue;
      var cs = getComputedStyle(el);
      if (cs.position !== 'fixed' && cs.position !== 'sticky') { el.__fchaiNotFixed = true; continue; }
      var r = el.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) continue;
      if (el.querySelector('video')) continue;
      var edge = r.bottom >= vh() - 6 || r.top <= 6;
      var small = r.height <= vh() * 0.3;
      var cls = (el.id || '') + ' ' + (el.getAttribute('class') || '');
      var adLike = el.tagName === 'IFRAME' || !!el.querySelector('iframe') || externalImgLink(el) || AD_WORDS.test(cls);
      if (edge && small && adLike) hide(el);
    }
    // 3) ảnh banner dẫn ra trang ngoài
    var as = document.querySelectorAll('a[href]');
    for (var a = 0; a < as.length; a++) {
      var an = as[a];
      if (an.__fchaiHidden) continue;
      if (isExternal(an.href) && an.querySelector('img') && !an.querySelector('video')) hide(an);
    }
    // 4) khung iframe quảng cáo (không phải khung video)
    var fr = document.querySelectorAll('iframe');
    for (var f = 0; f < fr.length; f++) {
      var fe = fr[f];
      if (fe.__fchaiHidden) continue;
      var src = fe.getAttribute('src') || '';
      if (!src || !isExternal(src)) continue;
      var fb = fe.getBoundingClientRect();
      if (fb.width < 1 || fb.height < 1) continue;
      if (isPlayerBox(fe)) continue;
      hide(fe);
    }
  }

  // ---------- tự xem toàn màn hình khi vào trận ----------
  var CHAT_RE = /chat|comment|disqus|livechat|messag|discuss|binh-?luan|talk|forum|tawk|crisp|zalo|fb-|facebook|twitter|social/i;
  function isChatLike(el) {
    var t = (el.getAttribute('src') || '') + ' ' + (el.id || '') + ' ' + (el.getAttribute('class') || '') + ' ' + (el.getAttribute('name') || '') + ' ' + (el.getAttribute('title') || '');
    if (CHAT_RE.test(t)) return true;
    for (var p = el.parentElement, n = 0; p && n < 4; p = p.parentElement, n++) {
      var pt = (p.id || '') + ' ' + (p.getAttribute('class') || '');
      if (/chat|comment|disqus|binh-?luan/i.test(pt)) return true;
    }
    return false;
  }
  function findPlayer() {
    var list = document.querySelectorAll('video, iframe'), best = null, bestScore = -1;
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      if (el.__fchaiHidden || !isPlayerBox(el)) continue;
      if (isChatLike(el)) continue;
      var r = el.getBoundingClientRect();
      var ratio = r.width / r.height;
      // điểm: ưu tiên thẻ video, rồi khung gần 16:9, rồi diện tích
      var score = (el.tagName === 'VIDEO' ? 1000 : 0) + (100 - Math.abs(ratio - 1.778) * 100) + (r.width * r.height) / (vw() * vh());
      if (score > bestScore) { bestScore = score; best = el; }
    }
    return best;
  }
  function styleOnce() {
    if (document.getElementById('fchai-style')) return;
    var s = document.createElement('style');
    s.id = 'fchai-style';
    s.textContent =
      'html.fchai-fs,html.fchai-fs body{overflow:hidden!important;background:#000!important;}' +
      '.fchai-anc{transform:none!important;filter:none!important;perspective:none!important;contain:none!important;will-change:auto!important;overflow:visible!important;}' +
      '.fchai-player{position:fixed!important;top:0!important;left:0!important;right:0!important;bottom:0!important;' +
      'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;min-height:0!important;' +
      'margin:0!important;padding:0!important;border:0!important;z-index:2147483647!important;background:#000!important;' +
      'object-fit:contain!important;display:block!important;}';
    (document.head || document.documentElement).appendChild(s);
  }
  function unmuteOnce(el) {
    try {
      var vs = [];
      if (el.tagName === 'VIDEO') vs = [el];
      else {
        try { var d = el.contentDocument; if (d) vs = [].slice.call(d.querySelectorAll('video')); } catch (e) {}  // chỉ iframe cùng nguồn
      }
      for (var i = 0; i < vs.length; i++) {
        var v = vs[i];
        v.muted = false; v.volume = 1;
        var pr = v.play();
        if (pr && pr.catch) pr.catch(function () {});
      }
    } catch (e) {}
  }
  function enter(el) {
    el = el || findPlayer();
    if (!el) return false;
    styleOnce();
    window.__fchaiEl = el;
    for (var p = el.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      p.classList.add('fchai-anc');
    }
    el.classList.add('fchai-player');
    document.documentElement.classList.add('fchai-fs');
    try {
      el.setAttribute('allow', 'autoplay; fullscreen; encrypted-media; picture-in-picture');
      el.setAttribute('allowfullscreen', '');
    } catch (e) {}
    window.__fchaiFS = true;
    var n = 0;
    unmuteOnce(el);
    var t = setInterval(function () { unmuteOnce(el); if (++n > 20) clearInterval(t); }, 1000);
    if (window.FchaiBridge) FchaiBridge.onPlayer(true);
    return true;
  }
  function exit() {
    var el = window.__fchaiEl;
    document.documentElement.classList.remove('fchai-fs');
    if (el) el.classList.remove('fchai-player');
    var anc = document.querySelectorAll('.fchai-anc');
    for (var i = 0; i < anc.length; i++) anc[i].classList.remove('fchai-anc');
    if (window.FchaiBridge) FchaiBridge.onPlayer(false);
  }
  window.__fchaiExit = exit;
  window.__fchaiEnter = function () { enter(); };

  function tick() {
    cleanAds();
    var path = location.pathname.replace(/\/+$/, '');
    var isHome = path === '' || path === '/index.html';
    if (!window.__fchaiFS && !isHome) {
      var p = findPlayer();
      if (p) enter(p);
    }
    if (window.__fchaiFS && isHome) { exit(); window.__fchaiFS = false; }  // quay lại trang chủ (trang đơn)
  }
  setInterval(tick, 500);
  tick();

  // dọn quảng cáo ngay khi trang vừa thêm phần tử mới (không phải chờ nhịp 0.5 giây)
  var pending = false;
  function scheduleClean() {
    if (pending) return;
    pending = true;
    setTimeout(function () { pending = false; try { cleanAds(); } catch (e) {} }, 60);
  }
  try {
    new MutationObserver(scheduleClean).observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}
})();
