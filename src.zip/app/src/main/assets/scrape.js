(function () {
  try {
    function abs(u) { try { return new URL(u, location.href).href; } catch (e) { return u || ''; } }
    function txt(el) { return ((el && el.textContent) || '').replace(/\s+/g, ' ').trim(); }
    function src(img) {
      return abs(img.currentSrc || img.getAttribute('data-src') || img.getAttribute('data-lazy-src') ||
        img.getAttribute('data-original') || img.src || '');
    }
    function isTeamImg(img) { return /football\/team|\/team\/|team_logo|\/logo/i.test(src(img)); }
    function isIcon(img) {
      var s = src(img);
      return !s || /Icon_|icon\.svg|live-icon|calendar-icon|imgts\.com|faunbrook|\.svg(\?|$)/i.test(s);
    }
    function teamImgs(el) {
      var all = [].slice.call(el.querySelectorAll('img'));
      var t = all.filter(isTeamImg);
      if (t.length) return t;
      return all.filter(function (i) { return !isIcon(i); });
    }
    function pathKey(u) {
      try { return new URL(u, location.href).pathname.replace(/\/+$/, ''); } catch (e) { return u; }
    }
    function title(s) {
      return s.split('-').map(function (w) { return w ? w.charAt(0).toUpperCase() + w.slice(1) : w; }).join(' ');
    }
    function slugNames(u) {
      var p = pathKey(u).split('/').pop() || '';
      var m = p.match(/^(.*?)-vs-(.*?)-luc-/i) || p.match(/^(.*?)-vs-(.*)$/i);
      if (!m) return ['', ''];
      return [title(m[1]), title(m[2])];
    }
    function nameNear(img, fallback, boundary) {
      var alt = (img.getAttribute('alt') || '').trim();
      if (alt && alt.length < 40 && !/logo|team|icon/i.test(alt)) return alt;
      var p = img.parentElement;
      for (var k = 0; k < 3 && p && p !== boundary; k++) {
        var t = txt(p);
        if (t && t.length <= 40 && !/\d/.test(t)) return t;
        p = p.parentElement;
      }
      return fallback;
    }

    var anchors = [].slice.call(document.querySelectorAll('a[href*="/truc-tiep/"]'));
    var cards = [];
    var seenEl = [];
    anchors.forEach(function (a) {
      var el = a, found = null;
      for (var i = 0; i < 8 && el && el !== document.body; i++) {
        var n = teamImgs(el).length;
        if (n >= 2) { found = (n <= 4) ? el : null; break; }
        el = el.parentElement;
      }
      if (found) {
        var idx = seenEl.indexOf(found);
        if (idx < 0) { seenEl.push(found); cards.push({ el: found, as: [a] }); }
        else cards[idx].as.push(a);
      } else {
        cards.push({ el: null, as: [a] });
      }
    });

    var out = [], seen = {};
    cards.forEach(function (c) {
      var primary = null, provs = [];
      c.as.forEach(function (a) {
        var t = txt(a);
        if (/xem\s*c(ù|u)ng/i.test(t)) {
          provs.push({ n: t.replace(/xem\s*c(ù|u)ng/i, '').trim() || 'Nguồn', u: abs(a.href) });
        } else if (!primary || /xem\s*ngay/i.test(t)) {
          primary = a;
        }
      });
      if (!primary) primary = c.as[0];
      var url = abs(primary.href);
      var key = pathKey(url);
      if (seen[key]) return;
      seen[key] = 1;

      var sn = slugNames(url);
      var home = sn[0], away = sn[1], hl = '', al = '', league = '';
      var live = false, score = '', minute = '', time = '';

      if (c.el) {
        var imgs = teamImgs(c.el);
        hl = src(imgs[0]); al = src(imgs[1]);
        home = nameNear(imgs[0], sn[0], c.el);
        away = nameNear(imgs[1], sn[1], c.el);
        var ct = txt(c.el);
        var mt = ct.match(/(\d{1,2}):(\d{2})\s+(\d{1,2}\/\d{1,2}(?:\/\d{2,4})?)/);
        if (mt) {
          time = mt[1] + ':' + mt[2] + '  ' + mt[3];
        } else if (/kết thúc|\bFT\b/i.test(ct)) {
          time = 'Đã kết thúc';
        } else if (c.el.querySelector('img[src*="live-icon"]') ||
                   /Hiệp\s*\d|nghỉ giữa hiệp|đang diễn ra|\bLIVE\b|\bHT\b/i.test(ct)) {
          live = true;
          var mi = ct.match(/Hiệp\s*\d\s*:?\s*(\d{1,3})\s*'/i) || ct.match(/(\d{1,3})\s*'/);
          if (mi) minute = mi[1] + "'";
          var ct2 = ct.replace(/Hiệp\s*\d\s*:?\s*\d{1,3}\s*'/gi, ' ');
          var sc = ct2.match(/(\d{1,2})\s*:\s*(\d{1,2})/);
          if (sc) score = sc[1] + ' : ' + sc[2];
        }
        if (home) {
          var i2 = ct.indexOf(home);
          if (i2 > 2 && i2 < 80) league = ct.substring(0, i2).trim();
          if (league.length > 50) league = '';
        }
      }
      if (!home) home = 'Trận đấu';
      out.push({
        url: url, home: home, away: away, hl: hl, al: al, league: league,
        live: live, score: score, minute: minute, time: time, p: provs
      });
    });

    var bodyText = document.body ? (document.body.innerText || document.body.textContent || '') : '';
    return JSON.stringify({
      m: out,
      dbg: 'liên kết trận: ' + anchors.length + ' | thẻ: ' + cards.length + ' | tiêu đề: ' +
        (document.title || '').slice(0, 40) + ' | độ dài chữ: ' + bodyText.length
    });
  } catch (e) {
    return JSON.stringify({ m: [], dbg: 'lỗi script: ' + e });
  }
})();
