(function () {
  // Đọc mục "Xem tiếp của bạn" của trang phim rồi gửi về app (FchaiBridge.setMovies)
  try { if (window.__tvRecentT) clearInterval(window.__tvRecentT); } catch (e) {}
  if (!window.FchaiBridge || !FchaiBridge.setMovies) return;
  var tries = 0, lastSent = null;
  function norm(s) { return (s || '').replace(/\s+/g, ' ').trim(); }
  function findHeading() {
    var best = null, all = document.querySelectorAll('h1,h2,h3,h4,h5,div,span,p,a,b,strong');
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (el.children.length > 2) continue;
      var t = norm(el.textContent).toLowerCase();
      if (t.length > 40) continue;
      if (/^xem tiếp( của bạn)?$/.test(t)) { if (!best || best.contains(el)) best = el; }
    }
    return best;
  }
  function imgOf(root) {
    var im = root.querySelector('img');
    if (im) {
      var s = im.currentSrc || im.getAttribute('src') || im.getAttribute('data-src') || im.getAttribute('data-original') || '';
      if (s && s.indexOf('data:') !== 0) return { src: s, alt: im.getAttribute('alt') || '' };
    }
    var els = root.querySelectorAll('*');
    for (var i = -1; i < els.length; i++) {
      var e = i < 0 ? root : els[i];
      var bg = (e.style && e.style.backgroundImage) || '';
      if (!bg || bg === 'none') { try { bg = getComputedStyle(e).backgroundImage; } catch (x) { bg = ''; } }
      var m = /url\(["']?([^"')]+)["']?\)/.exec(bg || '');
      if (m && m[1].indexOf('data:') !== 0) return { src: m[1], alt: '' };
    }
    return null;
  }
  function progressOf(card) {
    var t = norm(card.textContent);
    var m = /(\d+)\s*(?:m|p|phút)\s*\/\s*(\d+)\s*(?:m|p|phút)/i.exec(t);
    if (m && +m[2] > 0) return Math.max(0, Math.min(1, +m[1] / +m[2]));
    var els = card.querySelectorAll('[style*="width"]');
    for (var i = 0; i < els.length; i++) {
      var w = /width:\s*([\d.]+)%/.exec(els[i].getAttribute('style') || '');
      if (w && +w[1] > 0 && +w[1] < 100.5) return +w[1] / 100;
    }
    return 0;
  }
  function labelOf(card) {
    var t = norm(card.textContent);
    var m = /(Tập\s*[^•|\d]*\d*[^•|]*?)(?=\s*[•|]|\s*\d+\s*m\b|$)/i.exec(t);
    return m ? norm(m[1]) : '';
  }
  function collect() {
    var h = findHeading();
    if (!h) return null;
    var sec = h, anchors = [];
    for (var up = 0; up < 8 && sec.parentElement; up++) {
      sec = sec.parentElement;
      anchors = [].filter.call(sec.querySelectorAll('a[href]'), function (a) { return a.querySelector('img') || imgOf(a); });
      if (anchors.length) break;
    }
    if (!anchors.length) return [];
    var seen = {}, out = [];
    anchors.forEach(function (a) {
      var url = a.href;
      if (!url || seen[url] || url.indexOf('http') !== 0) return;
      // thẻ = tổ tiên lớn nhất chỉ chứa đúng một liên kết này
      var card = a;
      while (card.parentElement && card.parentElement !== sec &&
             [].filter.call(card.parentElement.querySelectorAll('a[href]'), function (x) { return anchors.indexOf(x) >= 0; }).length === 1) card = card.parentElement;
      var im = imgOf(card) || imgOf(a);
      if (!im) return;
      seen[url] = 1;
      var title = norm(a.getAttribute('title') || a.getAttribute('aria-label') || im.alt || '');
      out.push({ title: title, url: url, poster: im.src, progress: progressOf(card), label: labelOf(card) });
    });
    return out.slice(0, 6);
  }
  function tick() {
    tries++;
    var r;
    try { r = collect(); } catch (e) { r = null; }
    if (r && (r.length || tries >= 8)) {
      var j = JSON.stringify(r);
      if (j !== lastSent) { lastSent = j; try { FchaiBridge.setMovies(j); } catch (e) {} }
    }
    if (tries >= 40) clearInterval(window.__tvRecentT);
  }
  window.__tvRecentT = setInterval(tick, 1500);
  setTimeout(tick, 400);
})();
