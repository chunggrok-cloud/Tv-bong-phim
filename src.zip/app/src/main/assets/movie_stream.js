(function () {
  // Giao diện tối giản chọn tập / luồng cho trang phim 500phim:
  // - tự chọn luồng đầu tiên (bỏ qua luồng QC) khi mở phim mới
  // - hiện lớp "Danh sách tập" gọn, nút "Luồng khác" mở danh sách luồng
  // - __fchaiPick.openStreams(true): đổi luồng khi đang xem (giữ tập, tua tới phút đang xem)
  if (window.__fchaiPick) { try { window.__fchaiPick.rescan(); } catch (e) {} return; }

  function norm(s) { return (s || '').replace(/\s+/g, ' ').trim(); }
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function ss(k, v) { try { if (v === undefined) return sessionStorage.getItem(k); if (v === null) sessionStorage.removeItem(k); else sessionStorage.setItem(k, v); } catch (e) {} return null; }
  function armed() { return +ss('__fchaiArm') > Date.now(); }
  function arm() { ss('__fchaiArm', String(Date.now() + 25000)); }
  function mine(el) { return !!(el.closest && el.closest('#fchai-pick,#fchai-epbar')); }
  function visible(el) { try { var r = el.getBoundingClientRect(); return r.width > 4 && r.height > 4; } catch (e) { return false; } }

  var P = { order: [], on: false, panel: 'eps', mode: 'enter', sel: 0, nodes: [], streams: [], eps: [], root: null, shownOnce: false, busy: false };

  // ---------------- đọc luồng và tập từ trang ----------------
  function shortName(raw) {
    var m = raw.match(/\(([^)]*)\)/), n = m ? m[1] : raw.replace(/\d+\s*tập/i, '');
    n = n.replace(/\s*[-–]\s*QC\b/i, '').replace(/\bQC\b/i, '').replace(/\s+/g, ' ').trim();
    if (/song\s*ng/i.test(n)) return 'Song ngữ';
    if (/viet\s*sub|việt\s*sub/i.test(n)) return 'Vietsub';
    if (/thuy[eêế]t\s*minh|thuyết/i.test(n)) return 'Thuyết minh';
    if (/l[oồ]ng\s*ti[eế]ng/i.test(n)) return 'Lồng tiếng';
    return n ? n.charAt(0).toUpperCase() + n.slice(1) : 'Luồng';
  }
  function streamCurrent(list) {
    for (var i = 0; i < list.length; i++) {
      var e = list[i].el, c = (e.getAttribute('class') || '') + ' ' + ((e.parentElement && e.parentElement.getAttribute('class')) || '');
      if (e.getAttribute('aria-selected') === 'true' || e.getAttribute('aria-current') || /(^|[\s_-])(active|current|selected|on|playing)([\s_-]|$)/i.test(c)) return i;
    }
    var bg = list.map(function (s) { try { return getComputedStyle(s.el).backgroundColor; } catch (e) { return ''; } });
    for (var j = 0; j < bg.length; j++) {
      var same = bg.filter(function (b) { return b === bg[j]; }).length;
      if (same === 1 && list.length > 2) return j;
    }
    return 0;
  }
  function scanStreams() {
    var cand = document.body.querySelectorAll('a,button,li,div,span,label');
    var groups = [], parents = [];
    for (var i = 0; i < cand.length; i++) {
      var el = cand[i];
      if (mine(el) || !visible(el)) continue;
      var t = norm(el.textContent);
      if (t.length < 6 || t.length > 90 || !/\d+\s*tập/i.test(t)) continue;
      if (t.replace(/\d+\s*tập/ig, '').replace(/\bQC\b/g, '').replace(/[^A-Za-zÀ-ỹ]/g, '').length < 3) continue;
      var deeper = false, ch = el.children;
      for (var k = 0; k < ch.length; k++) { if (norm(ch[k].textContent).length >= t.length - 6) { deeper = true; break; } }
      if (deeper) continue;
      var pr = el.parentElement, gi = parents.indexOf(pr);
      if (gi < 0) { parents.push(pr); groups.push([]); gi = parents.length - 1; }
      groups[gi].push(el);
    }
    var best = [];
    for (var g = 0; g < groups.length; g++) if (groups[g].length > best.length) best = groups[g];
    var out = best.map(function (el) {
      var t = norm(el.textContent), c = t.match(/(\d+)\s*tập/i);
      return { el: el, name: shortName(t), qc: /\bQC\b/.test(t), count: c ? +c[1] : 0 };
    });
    // tên trùng nhau (ví dụ hai luồng "Song ngữ"): dùng tên đầy đủ của trang để phân biệt
    out.forEach(function (s) {
      var dup = out.filter(function (o) { return o.name === s.name && o.qc === s.qc; }).length > 1;
      if (dup) {
        var t = norm(s.el.textContent), m = t.match(/\(([^)]*)\)/), full = (m ? m[1] : t).replace(/\s*[-–]\s*QC\b/i, '').replace(/\bQC\b/i, '').replace(/\d+\s*tập/i, '').trim();
        s.name = full ? full.charAt(0).toUpperCase() + full.slice(1) : s.name;
      }
    });
    out.forEach(function (s) {
      var dup = out.filter(function (o) { return o.name === s.name && o.qc === s.qc; }).length > 1;
      if (dup) { var m = norm(s.el.textContent).match(/^\S+/); if (m) s.name += ' · ' + m[0]; }
    });
    var cur = streamCurrent(out);
    out.forEach(function (s, i) { s.cur = (i === cur); });
    return out;
  }
  var EP_RE = /^\W*(tập|tap|ep|episode)\s*\.?\s*(\d+)\W*$/i;
  function scanEps() {
    var cand = document.body.querySelectorAll('a,button,li,div,span');
    var groups = [], parents = [];
    for (var i = 0; i < cand.length; i++) {
      var el = cand[i];
      if (mine(el) || !visible(el)) continue;
      var t = norm(el.textContent);
      if (t.length > 14 || !EP_RE.test(t)) continue;
      if (el.querySelector('a,button')) continue;
      var pr = el.parentElement, gi = parents.indexOf(pr);
      if (gi < 0) { parents.push(pr); groups.push([]); gi = parents.length - 1; }
      groups[gi].push(el);
    }
    var best = [];
    for (var g = 0; g < groups.length; g++) if (groups[g].length > best.length) best = groups[g];
    if (best.length < 2) return [];
    var cur = -1;
    for (var j = 0; j < best.length; j++) {
      var e = best[j], c = (e.getAttribute('class') || '') + ' ' + ((e.parentElement && e.parentElement.getAttribute('class')) || '');
      if (e.getAttribute('aria-current') || /(^|[\s_-])(active|current|selected|playing|watching)([\s_-]|$)/i.test(c)) { cur = j; break; }
    }
    return best.map(function (el, idx) {
      var n = norm(el.textContent).match(/\d+/);
      return { el: el, num: n ? +n[0] : idx + 1, label: 'Tập ' + (n ? n[0] : idx + 1), cur: idx === cur };
    });
  }
  function sig(eps) { return eps.length + ':' + (eps[0] ? norm(eps[0].el.textContent) : '') + ':' + (eps[0] && eps[0].el.parentElement ? eps[0].el.parentElement.children.length : 0); }

  // ---------------- giao diện lớp phủ ----------------
  function notify(on) { try { if (window.FchaiBridge && FchaiBridge.onPick) FchaiBridge.onPick(!!on); } catch (e) {} }
  function title() {
    var h = document.querySelector('h1'), t = h ? norm(h.textContent) : norm(document.title);
    t = t.replace(/\s*[-|–].*$/, '');
    return t.length > 60 ? t.slice(0, 60) : t;
  }
  function css() {
    if (document.getElementById('fchai-pickcss')) return;
    var st = document.createElement('style');
    st.id = 'fchai-pickcss';
    st.textContent = '#fchai-pick{position:fixed;inset:0;z-index:2147483646;background:#0B0F17;color:#fff;font-family:Roboto,Arial,sans-serif;overflow-y:auto;padding:5vh 6vw}' +
      '#fchai-pick.play{background:rgba(6,8,13,.94)}' +
      '#fchai-pick .ph{font-size:max(14px,1.5vw);color:#8FA3BF;letter-spacing:2px;margin-bottom:4px;text-transform:uppercase}' +
      '#fchai-pick .h{font-size:max(26px,3.2vw);font-weight:800}' +
      '#fchai-pick .sub{font-size:max(16px,1.6vw);color:#8FA3BF;margin-top:4px}' +
      '#fchai-pick .top{display:flex;align-items:flex-start;gap:20px}#fchai-pick .sp{flex:1}' +
      '#fchai-pick .btn,#fchai-pick .t,#fchai-pick .s{background:#1b2436;border:3px solid #29344c;border-radius:14px;font-weight:700;color:#fff}' +
      '#fchai-pick .btn{font-size:max(16px,1.8vw);padding:1.2vw 2.2vw;white-space:nowrap}' +
      '#fchai-pick .grid{display:grid;grid-template-columns:repeat(5,1fr);gap:1.6vw;margin-top:5vh}' +
      '#fchai-pick .t{font-size:max(18px,2.1vw);height:7vw;min-height:54px;display:flex;align-items:center;justify-content:center;position:relative}' +
      '#fchai-pick .t.cur{border-color:#4FC3F7;color:#4FC3F7}#fchai-pick .t small{position:absolute;bottom:5px;font-size:max(10px,.9vw);font-weight:600;color:#8FA3BF}' +
      '#fchai-pick .list{margin-top:5vh;max-width:60vw}' +
      '#fchai-pick .s{display:flex;align-items:center;font-size:max(20px,2.4vw);padding:1.6vw 2.4vw;margin-bottom:1.6vw}' +
      '#fchai-pick .s em{margin-left:auto;font-style:normal;font-size:max(13px,1.4vw);font-weight:600;color:#8FA3BF}#fchai-pick .s em.on{color:#4FC3F7}' +
      '#fchai-pick .qc{margin-left:1vw;background:#7a1f2b;border-radius:6px;padding:1px 9px;font-size:max(12px,1.2vw)}' +
      '#fchai-pick .foc{border-color:#fff!important;background:#2a3b5c!important;box-shadow:0 0 28px rgba(79,195,247,.45)}' +
      '#fchai-pick .hint{margin-top:4vh;color:#6F829E;font-size:max(12px,1.2vw)}';
    document.documentElement.appendChild(st);
  }
  function render() {
    css();
    if (!P.root) { P.root = document.createElement('div'); P.root.id = 'fchai-pick'; document.documentElement.appendChild(P.root); }
    var r = P.root, h = '', many = P.streams.length > 1;
    r.className = P.mode === 'play' ? 'play' : '';
    if (P.panel === 'eps') {
      var cs = null;
      for (var i = 0; i < P.streams.length; i++) if (P.streams[i].cur) cs = P.streams[i];
      h = '<div class="top"><div><div class="ph">' + esc(title()) + '</div><div class="h">Danh sách tập</div><div class="sub">' +
        (cs ? esc(cs.name) + (cs.qc ? ' (QC)' : '') + ' · ' : '') + P.eps.length + ' tập</div></div><div class="sp"></div>' +
        (many ? '<div class="btn" data-a="streams">⇄ Luồng khác</div>' : '') + '</div><div class="grid">';
      P.eps.forEach(function (e, i) { h += '<div class="t' + (e.cur ? ' cur' : '') + '" data-a="ep" data-i="' + i + '">' + esc(e.label) + (e.cur ? '<small>đang xem</small>' : '') + '</div>'; });
      h += '</div><div class="hint">OK: xem tập · Lên: Luồng khác · Back: về trang chủ phim</div>';
    } else {
      h = '<div class="ph">' + esc(title()) + '</div><div class="h">Luồng khác</div><div class="sub">Chọn luồng, rồi chọn tập</div><div class="list">';
      P.order.forEach(function (s, i) {
        h += '<div class="s" data-a="stream" data-i="' + s.idx + '">' + esc(s.name) + (s.qc ? '<span class="qc">QC</span>' : '') +
          '<em class="' + (s.cur ? 'on' : '') + '">' + (s.cur ? 'Đang xem' : (s.count ? s.count + ' tập' : '')) + '</em></div>';
      });
      h += '</div><div class="hint">OK: chọn luồng · Back: quay lại</div>';
    }
    r.innerHTML = h;
    P.nodes = [].slice.call(r.querySelectorAll('[data-a]'));
    if (P.sel >= P.nodes.length || P.sel < 0) P.sel = 0;
    focusSel();
  }
  function focusSel() {
    P.nodes.forEach(function (n, i) { n.classList.toggle('foc', i === P.sel); });
    var n = P.nodes[P.sel];
    if (n && n.scrollIntoView) try { n.scrollIntoView({ block: 'nearest' }); } catch (e) {}
  }
  function setOn(v) { if (P.on !== v) { P.on = v; notify(v); } }
  function close() {
    if (P.root) { try { P.root.remove(); } catch (e) {} P.root = null; }
    P.nodes = [];
    setOn(false);
  }

  function showEps(sel) {
    P.panel = 'eps'; P.mode = 'enter';
    var ci = -1;
    for (var i = 0; i < P.eps.length; i++) if (P.eps[i].cur) ci = i;
    P.sel = sel !== undefined ? sel : (ci >= 0 ? ci : 0);
    // chọn sẵn ô đầu tiên của lưới (không phải nút Luồng khác)
    render();
    var base = P.nodes.filter(function (n) { return n.getAttribute('data-a') === 'streams'; }).length;
    P.sel = Math.min(P.nodes.length - 1, (sel !== undefined ? sel : (ci >= 0 ? ci : 0)) + base);
    focusSel();
    setOn(true);
  }
  function orderStreams() {
    var arr = P.streams.map(function (s, i) { return { idx: i, name: s.name, qc: s.qc, count: s.count, cur: s.cur }; });
    P.order = arr.filter(function (s) { return !s.qc; }).concat(arr.filter(function (s) { return s.qc; }));
  }
  function showStreams(mode) {
    P.panel = 'streams'; P.mode = mode || 'enter';
    orderStreams();
    P.sel = 0;
    for (var i = 0; i < P.order.length; i++) if (P.order[i].cur) P.sel = i;
    render();
    setOn(true);
  }

  // ---------------- chọn luồng ----------------
  function refresh() { P.streams = scanStreams(); P.eps = scanEps(); }
  function waitEps(old, cb, n) {
    n = n || 0;
    var eps = scanEps();
    if (eps.length && (sig(eps) !== old || n >= 7)) { P.eps = eps; P.streams = scanStreams(); cb(); return; }
    if (n > 22) { P.eps = eps; P.streams = scanStreams(); cb(); return; }
    setTimeout(function () { waitEps(old, cb, n + 1); }, 300);
  }
  function curTime() { var v = findVideo(); return v && isFinite(v.currentTime) ? v.currentTime : 0; }
  function curEpNum() {
    var eps = scanEps();
    for (var i = 0; i < eps.length; i++) if (eps[i].cur) return eps[i].num;
    var m = location.href.match(/(?:tap|ep|episode)[-_/ ]?(\d+)/i);
    return m ? +m[1] : 0;
  }
  function switchStream(i, keepEp) {
    var s = P.streams[i];
    if (!s || s.cur) { if (P.mode === 'enter') { showEps(); } else close(); return; }
    var old = sig(P.eps), t = curTime(), ep = keepEp ? curEpNum() : 0, mode = P.mode;
    if (mode === 'play') { close(); ss('__fchaiResume', JSON.stringify({ t: t, at: Date.now() })); }
    arm();
    try { s.el.click(); } catch (e) {}
    P.busy = true;
    waitEps(old, function () {
      P.busy = false;
      if (mode === 'play') {
        var target = null;
        for (var k = 0; k < P.eps.length; k++) if (P.eps[k].num === ep) target = P.eps[k];
        if (!target && P.eps.length) target = P.eps[Math.min(P.eps.length - 1, Math.max(0, ep - 1))];
        arm();
        ss('__fchaiResume', JSON.stringify({ t: t, at: Date.now() }));
        if (target) try { target.el.click(); } catch (e) {}
      } else {
        showEps();
      }
    });
  }

  // ---------------- tua về phút cũ sau khi đổi luồng ----------------
  function findVideo() {
    var v = document.querySelector('video');
    if (v) return v;
    var fr = document.querySelectorAll('iframe');
    for (var i = 0; i < fr.length; i++) { try { var d = fr[i].contentDocument; if (d && (v = d.querySelector('video'))) return v; } catch (e) {} }
    return null;
  }
  setInterval(function () {
    var raw = ss('__fchaiResume');
    if (!raw) return;
    var o; try { o = JSON.parse(raw); } catch (e) { ss('__fchaiResume', null); return; }
    if (Date.now() - o.at > 120000) { ss('__fchaiResume', null); return; }
    var v = findVideo();
    if (v && v.readyState >= 1 && v.duration > 30) {
      if (o.t > 5 && o.t < v.duration - 5) { try { v.currentTime = o.t; } catch (e) {} }
      ss('__fchaiResume', null);
      try { var pr = v.play(); if (pr && pr.catch) pr.catch(function () {}); } catch (e) {}
    }
  }, 800);

  // ---------------- phím ----------------
  function geoMove(dir) {
    var cur = P.nodes[P.sel];
    if (!cur) return;
    var a = cur.getBoundingClientRect(), ax = a.left + a.width / 2, ay = a.top + a.height / 2, best = -1, bs = 1e9;
    P.nodes.forEach(function (n, i) {
      if (i === P.sel) return;
      var b = n.getBoundingClientRect(), dx = b.left + b.width / 2 - ax, dy = b.top + b.height / 2 - ay, p, c;
      if (dir === 'left') { if (dx > -4) return; p = -dx; c = Math.abs(dy); }
      else if (dir === 'right') { if (dx < 4) return; p = dx; c = Math.abs(dy); }
      else if (dir === 'up') { if (dy > -4) return; p = -dy; c = Math.abs(dx); }
      else { if (dy < 4) return; p = dy; c = Math.abs(dx); }
      var sc = p + c * 2.6;
      if (sc < bs) { bs = sc; best = i; }
    });
    if (best >= 0) { P.sel = best; focusSel(); }
  }
  function act() {
    var n = P.nodes[P.sel];
    if (!n) return 0;
    var a = n.getAttribute('data-a'), i = +n.getAttribute('data-i');
    if (a === 'streams') { showStreams('enter'); return 1; }
    if (a === 'stream') { switchStream(i, P.mode === 'play'); return 1; }
    if (a === 'ep') {
      var e = P.eps[i];
      close();
      arm();
      if (e) try { e.el.click(); } catch (x) {}
      return 1;
    }
    return 0;
  }
  window.__fchaiPick = {
    get on() { return P.on; },
    move: function (d) { if (P.on) geoMove(d); },
    act: act,
    back: function () {
      if (!P.on) return false;
      if (P.panel === 'streams') {
        if (P.mode === 'play') { close(); return true; }
        showEps(); return true;
      }
      return false;
    },
    count: function () { try { return scanStreams().length; } catch (e) { return 0; } },
    openStreams: function (play) {
      P.streams = scanStreams(); P.eps = scanEps();
      if (P.streams.length < 2) return 0;
      showStreams(play ? 'play' : 'enter');
      return 1;
    },
    rescan: function () { startWatch(); }
  };

  // ---------------- khởi động: tìm luồng/tập, tự chọn luồng đầu, hiện lớp phủ ----------------
  var watch = null, tries = 0;
  function startWatch() {
    if (watch) clearInterval(watch);
    tries = 0;
    watch = setInterval(function () {
      tries++;
      if (P.on || P.busy || window.__fchaiFS) { if (tries > 60) { clearInterval(watch); watch = null; } return; }
      var v = findVideo();
      if (armed() || (v && !v.paused && v.currentTime > 1)) { clearInterval(watch); watch = null; return; }
      refresh();
      if (P.eps.length < 2) { if (tries > 40) { clearInterval(watch); watch = null; } return; }
      clearInterval(watch); watch = null;
      // luồng đầu tiên không QC
      var first = -1;
      for (var i = 0; i < P.streams.length; i++) if (!P.streams[i].qc) { first = i; break; }
      if (first < 0 && P.streams.length) first = 0;
      if (first >= 0 && !P.streams[first].cur) {
        P.mode = 'enter';
        var old = sig(P.eps);
        try { P.streams[first].el.click(); } catch (e) {}
        P.busy = true;
        waitEps(old, function () { P.busy = false; showEps(); });
      } else {
        showEps();
      }
    }, 600);
  }
  startWatch();
})();
