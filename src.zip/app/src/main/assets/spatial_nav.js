(function () {
  // Điều hướng bằng phím mũi tên trên trang web: viền sáng nhảy giữa các thành phần bấm được.
  // Kotlin gọi: __tvNav.move('left'|'right'|'up'|'down'), __tvNav.act(), __tvNav.closeAd(), __tvNav.show(bool)
  if (window.__tvNav) return;
  var CUR = null, CACHE = null, CACHE_T = 0, ON = true;
  var st = document.createElement('style');
  st.id = '__tvnav-style';
  st.textContent = '.__tvfocus{outline:4px solid #6FA0FF !important;outline-offset:2px !important;border-radius:8px;box-shadow:0 0 0 7px rgba(111,160,255,.35) !important;transition:none !important}';
  (document.head || document.documentElement).appendChild(st);

  function vw() { return window.innerWidth || document.documentElement.clientWidth; }
  function vh() { return window.innerHeight || document.documentElement.clientHeight; }
  function txt(el) { return ((el.innerText || el.textContent || '') + '').replace(/\s+/g, ' ').trim(); }
  function isQC(el) { return /(^|[^A-Za-zÀ-ỹ])QC([^A-Za-zÀ-ỹ]|$)/.test(txt(el).slice(0, 140)); }

  function inDoc(el) { return el && el.isConnected; }

  function visible(el, r) {
    if (r.width < 8 || r.height < 8) return false;
    var cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) < 0.05) return false;
    return true;
  }

  function collect() {
    var now = Date.now();
    if (CACHE && now - CACHE_T < 500) return CACHE;
    var out = [], seen = new Set();
    var all = document.querySelectorAll('a[href],button,input,select,textarea,[role=button],[onclick],[tabindex],div,li,span,img,p,h3,h4,label');
    var n = Math.min(all.length, 4000);
    for (var i = 0; i < n; i++) {
      var el = all[i];
      if (el.id === '__tvnav-style' || (el.closest && el.closest('#fchai-ep, #__fchai_ep'))) continue;
      var tag = el.tagName;
      var native = tag === 'A' || tag === 'BUTTON' || tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA' ||
        el.getAttribute('role') === 'button' || el.hasAttribute('onclick') ||
        (el.hasAttribute('tabindex') && el.getAttribute('tabindex') !== '-1');
      var ok = native;
      if (!ok) {
        var cs = getComputedStyle(el);
        if (cs.cursor === 'pointer') {
          var p = el.parentElement;
          ok = !p || getComputedStyle(p).cursor !== 'pointer';
        }
      }
      if (!ok || seen.has(el)) continue;
      if (tag === 'INPUT' && (el.type === 'hidden')) continue;
      var r = el.getBoundingClientRect();
      if (!visible(el, r)) continue;
      // bị lớp khác che mất thì bỏ (trừ khi nằm ngoài màn hình, sẽ cuộn tới sau)
      var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      if (cx >= 0 && cy >= 0 && cx < vw() && cy < vh()) {
        var top = document.elementFromPoint(cx, cy);
        if (top && top !== el && !el.contains(top) && !top.contains(el)) continue;
      }
      seen.add(el);
      out.push({ el: el, r: r, qc: isQC(el) });
    }
    // bỏ thành phần chứa thành phần khác (chỉ giữ cái trong cùng), tránh viền bao cả khối lớn
    var els = out.map(function (o) { return o.el; });
    out = out.filter(function (o) {
      for (var j = 0; j < els.length; j++) { if (els[j] !== o.el && o.el.contains(els[j]) && o.el.tagName !== 'A' && o.el.tagName !== 'BUTTON') return false; }
      return true;
    });
    var hasOk = out.some(function (o) { return !o.qc; });
    if (hasOk) out = out.filter(function (o) { return !o.qc; });   // bỏ qua luồng (QC)
    CACHE = out; CACHE_T = now;
    return out;
  }

  function setCur(el) {
    if (CUR && CUR.classList) CUR.classList.remove('__tvfocus');
    CUR = el;
    if (CUR && ON) CUR.classList.add('__tvfocus');
  }

  function scrollTo(el) {
    var r = el.getBoundingClientRect();
    if (r.top < 70 || r.bottom > vh() - 70 || r.left < 20 || r.right > vw() - 20) {
      try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) {}
    }
    CACHE = null;
  }

  function startEl(list) {
    var best = null, bs = 1e9;
    list.forEach(function (o) {
      var r = o.r;
      if (r.bottom < 0 || r.top > vh()) return;
      var s = Math.max(0, r.top) * 3 + r.left;
      if (s < bs) { bs = s; best = o.el; }
    });
    return best || (list[0] && list[0].el);
  }

  function move(dir) {
    CACHE = null;
    var list = collect();
    if (!list.length) { if (dir === 'down') window.scrollBy(0, 300); if (dir === 'up') window.scrollBy(0, -300); return 0; }
    if (!inDoc(CUR) || !CUR.getBoundingClientRect().width) {
      var s = startEl(list); if (s) { setCur(s); scrollTo(s); }
      return 1;
    }
    var cr = CUR.getBoundingClientRect();
    var ccx = cr.left + cr.width / 2, ccy = cr.top + cr.height / 2;
    var best = null, bs = 1e12;
    list.forEach(function (o) {
      if (o.el === CUR || CUR.contains(o.el) || o.el.contains(CUR)) return;
      var r = o.r, cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      var dx = cx - ccx, dy = cy - ccy, along, perp, overlap;
      if (dir === 'right') { if (r.left < cr.right - cr.width * 0.5 && dx <= 4) return; if (dx <= 4) return; along = r.left - cr.right; perp = Math.abs(dy); overlap = Math.min(r.bottom, cr.bottom) - Math.max(r.top, cr.top); }
      else if (dir === 'left') { if (dx >= -4) return; along = cr.left - r.right; perp = Math.abs(dy); overlap = Math.min(r.bottom, cr.bottom) - Math.max(r.top, cr.top); }
      else if (dir === 'down') { if (dy <= 4) return; along = r.top - cr.bottom; perp = Math.abs(dx); overlap = Math.min(r.right, cr.right) - Math.max(r.left, cr.left); }
      else { if (dy >= -4) return; along = cr.top - r.bottom; perp = Math.abs(dx); overlap = Math.min(r.right, cr.right) - Math.max(r.left, cr.left); }
      if (along < 0) along = 0;
      if ((dir === 'left' || dir === 'right') && perp > Math.max(cr.height, r.height) * 1.2) return;   // trái/phải chỉ đi trong cùng hàng
      var score = along + perp * (overlap > 0 ? 1.2 : 4);
      if (score < bs) { bs = score; best = o.el; }
    });
    if (best) { setCur(best); scrollTo(best); return 1; }
    // hết thành phần theo hướng đó: cuộn trang thêm
    if (dir === 'down') window.scrollBy(0, 320);
    else if (dir === 'up') window.scrollBy(0, -320);
    CACHE = null;
    return 0;
  }

  // ---- đóng quảng cáo dạng lớp phủ trong trang (cửa sổ mới đã được app chặn riêng)
  function sameSite(u) {
    try { return new URL(u, location.href).hostname.replace(/^www\./, '') === location.hostname.replace(/^www\./, ''); } catch (e) { return true; }
  }
  function adLike(el) {
    if (el.querySelector('video')) return false;
    if (window.__fchaiEl && (el.contains(window.__fchaiEl) || window.__fchaiEl.contains(el))) return false;
    if (el.querySelector('input,textarea,select')) return false;   // hộp đăng nhập / tìm kiếm là của trang
    var fr = el.querySelectorAll('iframe');
    for (var i = 0; i < fr.length; i++) { if (fr[i].src && !sameSite(fr[i].src)) return true; }
    var as = el.querySelectorAll('a[href]');
    for (var j = 0; j < as.length; j++) { var h = as[j].getAttribute('href') || ''; if (/^https?:/i.test(h) && !sameSite(h)) return true; }
    var key = ((el.className && el.className.toString ? el.className.toString() : '') + ' ' + (el.id || '')).toLowerCase();
    return /(^|[\s_-])(ad|ads|adv|popup|pop|banner|promo|sponsor|qc|catfish|preroll)([\s_-]|$)/.test(key);
  }
  function findCloseBtn(el) {
    var c = el.querySelectorAll('button,a,div,span,i,svg');
    for (var i = 0; i < c.length; i++) {
      var x = c[i], t = txt(x), k = ((x.className && x.className.toString ? x.className.toString() : '') + ' ' + (x.id || '')).toLowerCase();
      var r = x.getBoundingClientRect();
      if (r.width < 6 || r.height < 6 || r.width > 160) continue;
      if (/^(×|✕|✖|x|X|close|đóng|bỏ qua|skip|tắt)$/i.test(t) || /close|dismiss|đóng|btn-x/.test(k)) return x;
    }
    return null;
  }
  function closeAd() {
    var W = vw(), H = vh(), best = null, ba = 0;
    var all = document.body ? document.body.querySelectorAll('div,aside,section,iframe,a,img') : [];
    for (var i = 0; i < all.length && i < 3000; i++) {
      var el = all[i];
      if (el.__tvnavKeep) continue;
      var cs = getComputedStyle(el);
      if (cs.position !== 'fixed' && cs.position !== 'absolute') continue;
      if (cs.display === 'none' || cs.visibility === 'hidden') continue;
      var r = el.getBoundingClientRect();
      var area = Math.max(0, Math.min(r.right, W) - Math.max(r.left, 0)) * Math.max(0, Math.min(r.bottom, H) - Math.max(r.top, 0));
      if (area < W * H * 0.06) continue;                          // quá nhỏ: không phải popup
      if (r.top <= 4 && r.height < H * 0.14 && r.width > W * 0.8) continue;   // thanh menu trên cùng
      var z = parseInt(cs.zIndex, 10) || 0;
      if (cs.position === 'absolute' && z < 100 && area < W * H * 0.5) continue;
      if (!adLike(el)) continue;
      if (area > ba) { ba = area; best = el; }
    }
    if (!best) return 0;
    var btn = findCloseBtn(best);
    if (btn) { try { btn.click(); } catch (e) {} }
    setTimeout(function () {
      if (best.isConnected && getComputedStyle(best).display !== 'none') { try { best.remove(); } catch (e) {} }
      try { if (document.body.style.overflow === 'hidden') document.body.style.overflow = ''; } catch (e) {}
    }, 150);
    CACHE = null;
    return 1;
  }

  // OK: đóng quảng cáo nếu có; ngược lại trả toạ độ để app bấm thật vào phần tử đang sáng
  function act() {
    if (closeAd()) return JSON.stringify({ t: 'ad' });
    if (!inDoc(CUR)) { var l = collect(); var s = startEl(l); if (!s) return JSON.stringify({ t: 'none' }); setCur(s); scrollTo(s); }
    scrollTo(CUR);
    var r = CUR.getBoundingClientRect();
    var d = window.devicePixelRatio || 1;
    var tag = CUR.tagName;
    return JSON.stringify({ t: 'tap', x: (r.left + r.width / 2) * d, y: (r.top + r.height / 2) * d, input: (tag === 'INPUT' || tag === 'TEXTAREA') ? 1 : 0 });
  }

  function show(on) {
    ON = !!on;
    if (CUR && CUR.classList) { if (ON) CUR.classList.add('__tvfocus'); else CUR.classList.remove('__tvfocus'); }
  }

  window.__tvNav = { move: move, act: act, closeAd: closeAd, show: show };
})();
