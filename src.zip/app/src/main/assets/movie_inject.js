(function () {
  if (window.__fchaiInjected) return;
  window.__fchaiInjected = true;
  var ADBLOCK = window.__fchaiAdblock !== false;

  // ---------- tiện ích ----------
  function baseHost(h) { var p = String(h).split('.'); return p.slice(-2).join('.'); }
  var SITE = baseHost(location.hostname);
  function isExternal(u) {
    try {
      var x = new URL(u, location.href);
      if (x.protocol !== 'http:' && x.protocol !== 'https:') return false;
      if (x.hostname.indexOf('500phim') !== -1) return false;
      return baseHost(x.hostname) !== SITE;
    } catch (e) { return false; }
  }
  function vw() { return window.innerWidth || document.documentElement.clientWidth; }
  function vh() { return window.innerHeight || document.documentElement.clientHeight; }
  function txt(el) { return ((el && el.textContent) || '').replace(/\s+/g, ' ').trim(); }
  function hide(el) {
    if (!el || el.__fchaiHidden) return;
    if (el.classList && el.classList.contains('fchai-player')) return;
    if (window.__fchaiEl && el.contains && el.contains(window.__fchaiEl)) return;
    el.__fchaiHidden = true;
    el.style.setProperty('display', 'none', 'important');
  }
  function isPlayerBox(el) {
    var r = el.getBoundingClientRect();
    if (r.width < vw() * 0.6 || r.height < 120) return false;
    var ratio = r.width / r.height;
    return ratio >= 1.4 && ratio <= 2.4;   // khung hình ~16:9
  }

  // ---------- chặn quảng cáo (phần hiển thị) ----------
  var AD_WORDS = /(^|[-_ ])(ads?|adv|advert\w*|popup|popunder|catfish|sponsor\w*|floating-?ad|banner-?ads?)([-_ ]|$)/i;
  function externalImgLink(el) {
    if (el.tagName === 'A') return isExternal(el.href) && !!el.querySelector('img');
    var as = el.querySelectorAll('a[href]');
    for (var i = 0; i < as.length; i++) {
      if (isExternal(as[i].href) && as[i].querySelector('img')) return true;
    }
    return false;
  }
  function cleanAds() {
    if (!ADBLOCK || !document.body) return;
    var known = document.querySelectorAll('ins.adsbygoogle,[id^="google_ads"],[class*="adsbygoogle"],[id*="popunder"]');
    for (var k = 0; k < known.length; k++) hide(known[k]);
    // banner dán cố định ở mép trên hoặc dưới màn hình
    var els = document.body.querySelectorAll('div,section,aside,a,iframe,ul');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (el.__fchaiHidden || el.__fchaiNotFixed) continue;
      var cs = getComputedStyle(el);
      if (cs.position !== 'fixed' && cs.position !== 'sticky') { el.__fchaiNotFixed = true; continue; }
      var r = el.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) continue;
      if (el.querySelector('video')) continue;
      var edge = r.bottom >= vh() - 6 || r.top <= 6;
      var small = r.height <= vh() * 0.3;
      var cls = (el.id || '') + ' ' + (el.getAttribute('class') || '');
      var adLike = el.tagName === 'IFRAME' || !!el.querySelector('iframe') || externalImgLink(el) || AD_WORDS.test(cls);
      if (edge && small && adLike) hide(el);
    }
    // ảnh banner dẫn ra trang ngoài
    var as = document.querySelectorAll('a[href]');
    for (var a = 0; a < as.length; a++) {
      var an = as[a];
      if (an.__fchaiHidden) continue;
      if (isExternal(an.href) && an.querySelector('img') && !an.querySelector('video')) hide(an);
    }
    // khung iframe quảng cáo (không phải khung video)
    var fr = document.querySelectorAll('iframe');
    for (var f = 0; f < fr.length; f++) {
      var fe = fr[f];
      if (fe.__fchaiHidden) continue;
      var src = fe.getAttribute('src') || '';
      if (!src || !isExternal(src)) continue;
      var fb = fe.getBoundingClientRect();
      if (fb.width < 1 || fb.height < 1) continue;
      if (isPlayerBox(fe)) continue;
      hide(fe);
    }
  }


  // ---------- bỏ logo 500Phim ----------
  function hideLogo() {
    var cand = document.querySelectorAll('header a, header img, header svg, nav a, nav img, a[href="/"], a[href="/index.html"], a[class*="logo" i], img[class*="logo" i], [class*="logo" i], [id*="logo" i]');
    for (var i = 0; i < cand.length; i++) {
      var el = cand[i];
      if (el.__fchaiHidden || el.tagName === 'BODY' || el.tagName === 'HTML') continue;
      var r = el.getBoundingClientRect();
      if (r.width < 1 || r.top > 140 || r.left > vw() * 0.6 || r.width > vw() * 0.5 || r.height > 140) continue;
      var t = txt(el), alt = ((el.getAttribute('alt') || '') + ' ' + (el.getAttribute('src') || '') + ' ' + (el.getAttribute('class') || '') + ' ' + (el.id || ''));
      if (/500\s*phim/i.test(t) && t.length < 20 || /logo|500phim/i.test(alt)) hide(el);
    }
  }

  // ---------- trang phim: chỉ giữ ảnh/thông tin phim + danh sách tập ----------
  function trimDetail() {
    if (window.__fchaiFS || !document.body) return;
    var hs = document.querySelectorAll('h1,h2,h3,h4,div,span,p'), head = null;
    for (var i = 0; i < hs.length; i++) {
      var h = hs[i];
      if (h.children.length > 3) continue;
      if (/^danh sách tập/i.test(txt(h)) && txt(h).length < 40) { head = h; break; }
    }
    if (!head) return;
    try { trimExtras(); } catch (e) {}
    // đi từ tiêu đề "Danh sách tập" lên tới thân trang, ẩn mọi phần đứng sau nó
    var node = head;
    while (node && node !== document.body) {
      var sib = node.nextElementSibling;
      while (sib) {
        var nx = sib.nextElementSibling;
        if (sib.tagName !== 'SCRIPT' && sib.tagName !== 'STYLE' && !sib.__fchaiKeep) {
          if (sib.querySelector('video,iframe') || (window.__fchaiEl && sib.contains(window.__fchaiEl))) { sib.__fchaiKeep = true; }
          else if (!isEpisodeBlock(sib)) hide(sib);
        }
        sib = nx;
      }
      node = node.parentElement;
    }
  }
  function hideEl(x) { if (x && !x.__fchaiHidden) hide(x); }
  function climbRow(el, maxKids, maxLen) {
    var r = el;
    for (var i = 0; i < 3 && r.parentElement && r.parentElement !== document.body; i++) {
      var p = r.parentElement;
      if (p.children.length <= maxKids && txt(p).length <= maxLen) r = p; else break;
    }
    return r;
  }
  function trimExtras() {
    var all = document.body.querySelectorAll('div,p,span,a,button,h2,h3,h4,li,section,ul');
    for (var i = 0; i < all.length; i++) {
      var x = all[i];
      if (x.__fchaiHidden || x.__fchaiExt) continue;
      var t = txt(x), n = t.length;
      if (!n) continue;
      if (x.closest && x.closest('.fchai-player')) continue;
      // đoạn mô tả / "Nội dung phim" (chữ dài, không chứa nút tập)
      if (n > 80 && !x.querySelector('div,p,h1,h2,h3,h4,button,ul,li,img,svg,a') && !/(^|\s)tập\s*\d+/i.test(t.slice(0,30))) { x.__fchaiExt = 1; hideEl(x); continue; }
      if (/^nội dung phim/i.test(t) && n < 120) { x.__fchaiExt = 1; hideEl(x); continue; }
      // hàng tab: Tập phim | Gallery | Diễn viên | Đề xuất
      if (t === 'Gallery' || t === 'Diễn viên' || t === 'Đề xuất') { x.__fchaiExt = 1; hideEl(climbRow(x, 6, 60)); continue; }
      // trạng thái phát hành, lịch ra tập, nút Xem Ngay
    }
    // biểu tượng quà nổi
    var fx = document.body.querySelectorAll('div,a,button,img');
    for (var m = 0; m < fx.length; m++) {
      var f = fx[m];
      if (f.__fchaiHidden || f.__fchaiGift) continue;
      var cs = getComputedStyle(f);
      if (cs.position !== 'fixed') { f.__fchaiGift = 1; continue; }
      var gb = f.getBoundingClientRect();
      if (gb.width > 0 && gb.width < 130 && gb.height < 130 && !txt(f) && (f.tagName === 'IMG' || f.querySelector('img'))) { f.__fchaiGift = 1; hideEl(f); }
    }
  }
  // khối ngay sau tiêu đề có chứa các nút tập/máy chủ thì phải giữ lại
  function isEpisodeBlock(el) {
    var a = el.querySelectorAll('a,button,div[role="button"]'), n = 0;
    for (var i = 0; i < a.length && i < 400; i++) {
      var t = txt(a[i]);
      if (/^(\W*)(tập|tap|ep)\s*\d+/i.test(t) || /\d+\s*tập/i.test(t)) { n++; if (n >= 2) return true; }
    }
    return false;
  }

  // ---------- tự phóng to khi bấm chọn tập / bấm xem ----------
  var CHAT_RE = /chat|comment|disqus|livechat|messag|discuss|binh-?luan|talk|forum|tawk|crisp|zalo|fb-|facebook|twitter|social/i;
  function isChatLike(el) {
    var t = (el.getAttribute('src') || '') + ' ' + (el.id || '') + ' ' + (el.getAttribute('class') || '') + ' ' + (el.getAttribute('name') || '') + ' ' + (el.getAttribute('title') || '');
    if (CHAT_RE.test(t)) return true;
    for (var p = el.parentElement, n = 0; p && n < 4; p = p.parentElement, n++) {
      var pt = (p.id || '') + ' ' + (p.getAttribute('class') || '');
      if (/chat|comment|disqus|binh-?luan/i.test(pt)) return true;
    }
    return false;
  }
  function findPlayer() {
    var list = document.querySelectorAll('video, iframe'), best = null, bestScore = -1;
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      if (el.__fchaiHidden || !isPlayerBox(el)) continue;
      if (isChatLike(el)) continue;
      var r = el.getBoundingClientRect();
      var ratio = r.width / r.height;
      var score = (el.tagName === 'VIDEO' ? 1000 : 0) + (100 - Math.abs(ratio - 1.778) * 100) + (r.width * r.height) / (vw() * vh());
      if (score > bestScore) { bestScore = score; best = el; }
    }
    return best;
  }
  function styleOnce() {
    if (document.getElementById('fchai-style')) return;
    var s = document.createElement('style');
    s.id = 'fchai-style';
    s.textContent =
      'html.fchai-fs,html.fchai-fs body{overflow:hidden!important;background:#000!important;}' +
      'html.fchai-fs header:not(.fchai-anc),html.fchai-fs nav:not(.fchai-anc){display:none!important;}' +
      '.fchai-anc{transform:none!important;filter:none!important;perspective:none!important;contain:none!important;will-change:auto!important;overflow:visible!important;}' +
      '.fchai-player{position:fixed!important;top:0!important;left:0!important;right:0!important;bottom:0!important;' +
      'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;min-height:0!important;' +
      'margin:0!important;padding:0!important;border:0!important;z-index:2147483647!important;background:#000!important;' +
      'object-fit:contain!important;display:block!important;}';
    (document.head || document.documentElement).appendChild(s);
  }
  function unmuteOnce(el) {
    try {
      var vs = [];
      if (el.tagName === 'VIDEO') vs = [el];
      else {
        try { var d = el.contentDocument; if (d) vs = [].slice.call(d.querySelectorAll('video')); } catch (e) {}
      }
      for (var i = 0; i < vs.length; i++) {
        var v = vs[i];
        v.muted = false; v.volume = 1;
        var pr = v.play();
        if (pr && pr.catch) pr.catch(function () {});
      }
    } catch (e) {}
  }
  function enter(el) {
    el = el || findPlayer();
    if (!el) return false;
    styleOnce();
    window.__fchaiEl = el;
    window.__fchaiSuppress = false;
    for (var p = el.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      p.classList.add('fchai-anc');
    }
    el.classList.add('fchai-player');
    document.documentElement.classList.add('fchai-fs');
    try {
      el.setAttribute('allow', 'autoplay; fullscreen; encrypted-media; picture-in-picture');
      el.setAttribute('allowfullscreen', '');
    } catch (e) {}
    window.__fchaiFS = true;
    var n = 0;
    unmuteOnce(el);
    var t = setInterval(function () { unmuteOnce(el); if (++n > 20) clearInterval(t); }, 1000);
    if (window.FchaiBridge) FchaiBridge.onPlayer(true);
    return true;
  }
  var fsHidden = [];
  function hideChromeInFs() {
    var el = window.__fchaiEl;
    if (!el || !document.body) return;
    var list = document.body.querySelectorAll('div,section,aside,a,button,ul,span,img');
    for (var i = 0; i < list.length; i++) {
      var x = list[i];
      if (x.__fchaiFsChk) continue;
      var cs = getComputedStyle(x);
      if (cs.position !== 'fixed' && cs.position !== 'sticky') { x.__fchaiFsChk = true; continue; }
      if (x === el || x.contains(el) || el.contains(x) || x.classList.contains('fchai-anc')) continue;
      x.__fchaiFsChk = true;
      if (x.style.display !== 'none') { fsHidden.push([x, x.style.getPropertyValue('display'), x.style.getPropertyPriority('display')]); x.style.setProperty('display', 'none', 'important'); }
    }
  }
  function restoreChrome() {
    for (var i = 0; i < fsHidden.length; i++) {
      var h = fsHidden[i];
      try { h[0].style.removeProperty('display'); if (h[1]) h[0].style.setProperty('display', h[1], h[2]); h[0].__fchaiFsChk = false; } catch (e) {}
    }
    fsHidden = [];
  }
  function exit() {
    restoreChrome();
    var el = window.__fchaiEl;
    document.documentElement.classList.remove('fchai-fs');
    if (el) el.classList.remove('fchai-player');
    var anc = document.querySelectorAll('.fchai-anc');
    for (var i = 0; i < anc.length; i++) anc[i].classList.remove('fchai-anc');
    window.__fchaiFS = false;
    window.__fchaiSuppress = true;           // đã thoát: không tự phóng to lại cho tới khi bấm tập khác
    try { sessionStorage.removeItem('__fchaiArm'); } catch (e) {}
    if (window.FchaiBridge) FchaiBridge.onPlayer(false);
  }
  window.__fchaiExit = exit;
  window.__fchaiEnter = function () { enter(); };

  // "Mở khóa" tự phóng to: khi người dùng bấm một tập / nút xem, giữ trong 25 giây (qua cả việc chuyển trang)
  function arm() {
    window.__fchaiSuppress = false;
    try { sessionStorage.setItem('__fchaiArm', String(Date.now() + 25000)); } catch (e) {}
  }
  function armed() {
    try { return +sessionStorage.getItem('__fchaiArm') > Date.now(); } catch (e) { return false; }
  }
  var EP_CTX = /(tap|episode|ep-?list|list-?ep|server|danh-?sach-?tap|eps)/i;
  var EP_TEXT = /^(tập|tap|ep|episode|e)\s*\.?\s*\d+/i;
  var GO_TEXT = /(xem\s*(phim|ngay|tập|tiếp|trailer)?|play|phát|bắt đầu)/i;
  var EP_HREF = /(tap[-_/]?\d+|episode|\/ep[-_]?\d+|\/xem|watch)/i;
  function looksLikeEpisodeClick(el) {
    for (var i = 0; i < 5 && el && el !== document.body; i++, el = el.parentElement) {
      var tag = el.tagName;
      var isBtn = tag === 'A' || tag === 'BUTTON' || el.getAttribute('role') === 'button' || el.hasAttribute('onclick');
      if (!isBtn) continue;
      var t = txt(el);
      if (t.length > 40) return false;
      var href = (tag === 'A' && el.getAttribute('href')) || '';
      if (EP_TEXT.test(t) || EP_HREF.test(href)) return true;
      if (GO_TEXT.test(t) && t.length <= 25) return true;
      if (/^\d{1,4}$/.test(t)) {
        for (var p = el, n = 0; p && n < 4; p = p.parentElement, n++) {
          if (EP_CTX.test((p.id || '') + ' ' + (p.getAttribute('class') || ''))) return true;
        }
      }
      return false;
    }
    return false;
  }
  document.addEventListener('click', function (ev) {
    try { if (looksLikeEpisodeClick(ev.target)) arm(); } catch (e) {}
  }, true);
  document.addEventListener('play', function (ev) {
    try {
      var v = ev.target;
      if (v && v.tagName === 'VIDEO' && !window.__fchaiFS && !window.__fchaiSuppress && isPlayerBox(v) && !isChatLike(v)) enter(v);
    } catch (e) {}
  }, true);


  // ---------- thanh danh sách tập (điều khiển bằng remote) ----------
  var EPB = { items: [], idx: 0, bar: null, timer: null, on: false };
  var EP_LABEL = /^\W*(tập|tap|ep|episode)\s*\.?\s*\d+\W*$/i;
  function epCollect() {
    var cand = document.body.querySelectorAll('a,button,div[role="button"],li,span');
    var groups = [], parents = [];
    for (var i = 0; i < cand.length; i++) {
      var el = cand[i];
      if (el.closest && el.closest('#fchai-epbar')) continue;
      var t = txt(el);
      if (!t || t.length > 14) continue;
      var ok = EP_LABEL.test(t);
      if (!ok && /^\d{1,4}$/.test(t)) {
        for (var q = el, n = 0; q && n < 4; q = q.parentElement, n++) {
          if (EP_CTX.test((q.id || '') + ' ' + (q.getAttribute('class') || ''))) { ok = true; break; }
        }
      }
      if (!ok) continue;
      if (el.querySelector('a,button')) continue;
      var pr = el.parentElement, gi = parents.indexOf(pr);
      if (gi < 0) { parents.push(pr); groups.push([]); gi = parents.length - 1; }
      groups[gi].push(el);
    }
    var best = [];
    for (var g = 0; g < groups.length; g++) if (groups[g].length > best.length) best = groups[g];
    return best.length >= 2 ? best : [];
  }
  function epCurrent(list) {
    for (var i = 0; i < list.length; i++) {
      var e = list[i], c = (e.getAttribute('class') || '') + ' ' + ((e.parentElement && e.parentElement.getAttribute('class')) || '');
      if (e.getAttribute('aria-current') || /(^|[\s_-])(active|current|selected|playing|now|watching)([\s_-]|$)/i.test(c)) return i;
      if (e.tagName === 'A' && e.href && e.href.split('#')[0] === location.href.split('#')[0]) return i;
    }
    var m = location.href.match(/(?:tap|ep|episode)[-_/ ]?(\d+)/i);
    if (m) for (var j = 0; j < list.length; j++) { var d = txt(list[j]).match(/\d+/); if (d && +d[0] === +m[1]) return j; }
    return 0;
  }
  function epRender() {
    if (!EPB.bar) {
      var st = document.createElement('style');
      st.textContent = '#fchai-epbar{position:fixed;left:0;right:0;bottom:0;z-index:2147483647;padding:46px 20px 18px;background:linear-gradient(transparent,rgba(0,0,0,.88) 55%);color:#fff;font-family:sans-serif;display:none}' +
        '#fchai-epbar h4{margin:0 0 10px;font-size:18px;font-weight:600}' +
        '#fchai-epbar .row{display:flex;gap:10px;overflow:hidden;white-space:nowrap}' +
        '#fchai-epbar .ep{flex:0 0 auto;min-width:110px;padding:0 14px;height:54px;border-radius:8px;background:#2b3345;display:flex;align-items:center;justify-content:center;font-size:20px}' +
        '#fchai-epbar .ep.cur{background:#9be000;color:#111;font-weight:700}' +
        '#fchai-epbar .ep.foc{outline:4px solid #fff;outline-offset:-2px}';
      document.documentElement.appendChild(st);
      EPB.bar = document.createElement('div');
      EPB.bar.id = 'fchai-epbar';
      document.documentElement.appendChild(EPB.bar);
    }
    var cur = EPB.cur, h = '<h4>Danh sách tập • ◀ ▶ chọn, OK để xem • 1: lùi 10s • 3: tới 10s</h4><div class="row">';
    for (var i = 0; i < EPB.items.length; i++) {
      h += '<div class="ep' + (i === cur ? ' cur' : '') + (i === EPB.idx ? ' foc' : '') + '">' + txt(EPB.items[i]).replace(/</g, '&lt;') + '</div>';
    }
    EPB.bar.innerHTML = h + '</div>';
    var f = EPB.bar.querySelector('.foc');
    if (f && f.scrollIntoView) try { f.scrollIntoView({ block: 'nearest', inline: 'center' }); } catch (e) {}
  }
  function epNotify(on) { EPB.on = on; try { if (window.FchaiBridge && FchaiBridge.onEpBar) FchaiBridge.onEpBar(on); } catch (e) {} }
  function epTouch() {
    clearTimeout(EPB.timer);
    EPB.timer = setTimeout(window.__fchaiEp.hide, 6000);
  }
  window.__fchaiEp = {
    show: function () {
      var l = epCollect();
      if (!l.length) return 0;
      EPB.items = l; EPB.cur = epCurrent(l); EPB.idx = EPB.cur;
      epRender();
      EPB.bar.style.display = 'block';
      epNotify(true); epTouch();
      return l.length;
    },
    move: function (d) {
      if (!EPB.on) return;
      EPB.idx = Math.max(0, Math.min(EPB.items.length - 1, EPB.idx + d));
      epRender(); epTouch();
    },
    choose: function () {
      if (!EPB.on) return;
      var i = EPB.idx, el = EPB.items[i], same = (i === EPB.cur);
      window.__fchaiEp.hide();
      if (same || !el) return;
      arm();
      try { el.click(); } catch (e) {}
    },
    hide: function () {
      clearTimeout(EPB.timer);
      if (EPB.bar) EPB.bar.style.display = 'none';
      if (EPB.on) epNotify(false);
    }
  };

  function tick() {
    cleanAds();
    try { hideLogo(); trimDetail(); if (window.__fchaiFS) hideChromeInFs(); } catch (e) {}
    if (!window.__fchaiFS && !window.__fchaiSuppress && armed()) {
      var p = findPlayer();
      if (p) enter(p);
    }
  }
  setInterval(tick, 500);
  tick();

  var pending = false;
  function scheduleClean() {
    if (pending) return;
    pending = true;
    setTimeout(function () { pending = false; try { cleanAds(); hideLogo(); } catch (e) {} }, 60);
  }
  try {
    new MutationObserver(scheduleClean).observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}
})();
